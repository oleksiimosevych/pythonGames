from django.apps import AppConfig


class Certification82Config(AppConfig):
    name = 'certification82'
